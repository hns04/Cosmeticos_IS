USE sys;
CREATE DATABASE cosm001;
USE cosm001;

-- Creación e inserción: Incremento 1

CREATE TABLE Usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    pass VARCHAR(20) NOT NULL,
    admina BOOLEAN DEFAULT 0,
    estado BOOLEAN DEFAULT 1
);

INSERT INTO Usuario (email, pass, admina, estado) VALUES
	('dueno@example.com', '123', 1, 1),
	('janemendez@example.com', 'passw0rd', 0, 1),
	('miguelsanch@example.com', 'secure123', 0, 1),
	('emilyperez@example.com', 'password456', 0, 1),
	('susanamedina@example.com', 'abcd1234', 0, 1),
	('davidfelix@example.com', 'p@ssw0rd', 0, 1),
	('lauracardenas@example.com', 'user5678', 0, 1),
    ('paulvasquez@example.com', 'user88', 0, 1);

CREATE TABLE Cliente (
	userid INT PRIMARY KEY REFERENCES Usuario(id),
    nombres VARCHAR(255) NOT NULL,
    apellidos VARCHAR(255) NOT NULL,
    direccion VARCHAR(255) NULL,
    telefono VARCHAR (255) NULL,
    tarjeta VARCHAR(255) NULL
);

INSERT INTO Cliente (userid, nombres, apellidos, direccion, telefono, tarjeta) VALUES
	(2, 'Jane', 'Mendez', 'Avenida B, Los Olivos', '987654321', '9876-5432-1098-7654'),
	(3, 'Miguel', 'Sanchez', 'Calle C, San Isidro', '946813579', '2468-1357-9132-4681'),
	(4, 'Emily', 'Perez', 'Avenida D, La Victoria', '943216789', '5432-1678-3456-7891'),
	(5, 'Susana', 'Medina', 'Calle E, Los Olivos', '989123456', '7891-2345-6789-1234'),
	(6, 'David', 'Felix', 'Avenida F, Callao', '954789321', '6547-8932-1654-7893'),
	(7, 'Laura', 'Cardenas', 'Calle G, Ate', '987654123', '9876-5412-7893-6541'),
	(8, 'Paul', 'Vasquez', 'Calle A, Ate', '923456789', '1234-5678-9012-3456');

-- Procedimientos Almacenados
DELIMITER $$
CREATE PROCEDURE sp_verificarUsuario(IN p_email VARCHAR(255), IN p_password VARCHAR(20))
BEGIN
    DECLARE user_id INT;
    
    SELECT id INTO user_id FROM Usuario 
    WHERE email = p_email 
    AND pass=p_password 
    AND estado=1;
    
    IF user_id IS NOT NULL THEN
        SELECT 1 AS Acceso; -- Usuario encontrado
    ELSE
        SELECT 0 AS Acceso; -- Usuario no encontrado
    END IF;
END;
$$
DELIMITER ;





