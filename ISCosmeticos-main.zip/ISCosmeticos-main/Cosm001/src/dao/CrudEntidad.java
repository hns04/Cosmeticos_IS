package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;

public class CrudEntidad <Entidad> {

    public void mostrarRegistros(JTable tablaVista, String mostrarQUERIE){
    /*
    //  String[] Encabezado = ENCABEZADO_TECNICOS;
        DefaultTableModel Modelo = new DefaultTableModel(null, Encabezado);
        Table.setModel(Modelo);
        
        try {
            RS = ST.executeQuery(mostrarQUERIE);
            while (RS.next()) {
                CantReg++;
                Modelo.addRow(leerDB(RS));
            }
    //     FormatoTablas.FormatoTablaTecnicos(Table);
            Conecction.close();
        }catch(Exception ex){
            Mensajes.M1(ERROR_MOSTRAR + ex);
        }    
    */

    }
    public void insertarRegistro (Entidad e, String insertarQUERIE){
    /*
        try{
        PS = Conecction.prepareStatement(insertarQUERIE);
        escribirDB(PS,e);
        PS.executeUpdate();
        Mensajes.M1(CONFIRMACION_INSERTAR);
        Conecction.close();
        }  catch (Exception ex) {
            Mensajes.M1(ERROR_INSERTAR + ex);
        } 
    */
    }
    public Entidad consultarRegistroID(int entidadID, String consultarIdQUERIE){
    /*
        Entidad e = null;
        try {
            RS = ST.executeQuery(consultarIdQUERIE + entidadID + ";");
            if (RS.next()) {
                t = leerDB(RS);
            }  
            RS.close();
        } catch (Exception ex) {
            Mensajes.M1(ERROR_CONSULTAR + ex);
        }
        return t;  
    }

    */
    return null;
    }
    public void actualizarRegistro(Entidad e){
    
    }
    public void escribirDB(PreparedStatement PS, Entidad e){
    
    }
    public Entidad leerDB(ResultSet RS){
        //Tú generarás la fila.
    return null;
    }   
}
