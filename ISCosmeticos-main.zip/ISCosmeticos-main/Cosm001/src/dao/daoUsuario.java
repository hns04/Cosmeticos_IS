package dao;

/**
 *
 * @author Equipo
 */
public class daoUsuario {

}
