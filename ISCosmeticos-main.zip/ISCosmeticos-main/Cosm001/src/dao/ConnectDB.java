package dao;

import java.sql.*;
import dao.utiles.Parametros;
import dao.utiles.Msj;
import utiles.FormatoMsj;


public class ConnectDB  implements Parametros, Msj{

    public Connection connection;
    Statement ST;
    ResultSet RS;
    PreparedStatement PS;
    ResultSetMetaData MT;

    public ConnectDB() {
        try {
            Class.forName(DRIVER);
            connection = DriverManager.getConnection(RUTA, USER, PASS);
            ST = connection.createStatement();
            FormatoMsj.M1(EXITO_CONEXION);
        } catch (Exception ex) {
            FormatoMsj.M1(ERROR_CONEXION + ex);
        }
    }
}
