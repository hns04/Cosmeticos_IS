package dao.utiles;

public interface Msj {
    String EXITO_INSERTAR="Nuevo registro insertado con éxito.\n";
    String EXITO_UPD="Registro actualizado con éxito.\n";
    
    String EXITO_CONEXION="Éxito al conectarse a la BD.\n";
    
    String ERROR_ALL="Error al mostrar los registros.\n";
    String ERROR_CONSULTA="Error al mostrar la consulta.\n";
    String ERROR_INSERTAR="Error al insertar el nuevo registro.\n";
    String ERROR_UPD="Error al actualizar el registro.\n";
    String ERROR_CONEXION="El sistema no se pudo conectar a la base de datos.\n";
    String ERROR_LOGIN="El usuario y/o contraseña son inválidos.\n";
    String ERROR_USERNAME="Este nombre de usuario ya está en uso. Escoja otro.\n";
}
