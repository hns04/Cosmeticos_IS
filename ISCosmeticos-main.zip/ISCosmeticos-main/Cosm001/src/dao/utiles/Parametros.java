package dao.utiles;

public interface Parametros {
    
    String DRIVER="com.mysql.cj.jdbc.Driver";
    String DB="Cosm001";
    String RUTA="jdbc:mysql://localhost:3307/"+DB;
    String USER="root";
    String PASS="123A";
    
}
