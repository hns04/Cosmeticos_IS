package main;

public class main {
    
   
    public static void main(String[] args) {
        System.out.println("main: La clase-tabla cliente será mejorada.");

    }

}
