package entities;

/**
 *
 * @author Equipo
 */
public class Producto {

}
