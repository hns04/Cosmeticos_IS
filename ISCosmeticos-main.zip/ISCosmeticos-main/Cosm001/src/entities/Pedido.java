package entities;


public class Pedido {

}