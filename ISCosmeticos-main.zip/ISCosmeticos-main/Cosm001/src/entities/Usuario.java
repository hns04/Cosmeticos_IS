package entities;

public class Usuario {
    private String id;
    private String email; //'Ese correo ya está en uso'
    private String pass;
    private boolean admina;
    private boolean estado;

    public Usuario() {
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPass() {
        return pass;
    }
    public void setPass(String pass) {
        this.pass = pass;
    }
    public boolean isAdmin() {
        return admina;
    }
    public void setAdmin(boolean admin) {
        this.admina = admin;
    }
    public boolean isEstado() {
        return estado;
    }
    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}
